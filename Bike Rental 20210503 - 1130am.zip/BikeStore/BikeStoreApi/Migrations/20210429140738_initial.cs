﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace BikeStoreApi.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    CustID = table.Column<int>(type: "int", nullable: false),
                    FName = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    LName = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    Email = table.Column<string>(type: "text", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.CustID);
                });

            migrationBuilder.CreateTable(
                name: "PaymentStatus",
                columns: table => new
                {
                    PaymentStatusCode = table.Column<int>(type: "int", nullable: false),
                    PaymentMethod = table.Column<string>(type: "nchar(10)", fixedLength: true, maxLength: 10, nullable: true),
                    PaymentStatusDescription = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PaymentStatus", x => x.PaymentStatusCode);
                });

            migrationBuilder.CreateTable(
                name: "RentalRates",
                columns: table => new
                {
                    RateID = table.Column<int>(type: "int", nullable: false),
                    DailyRate = table.Column<decimal>(type: "money", nullable: true),
                    HourlyRate = table.Column<decimal>(type: "money", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RentalRates", x => x.RateID);
                });

            migrationBuilder.CreateTable(
                name: "Shops",
                columns: table => new
                {
                    ShopID = table.Column<int>(type: "int", nullable: false),
                    AddressLine1 = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    City = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ZipCode = table.Column<int>(type: "int", nullable: false),
                    State = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    AddressLine2 = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Shops", x => x.ShopID);
                });

            migrationBuilder.CreateTable(
                name: "SpecialFeatures",
                columns: table => new
                {
                    FeatureID = table.Column<int>(type: "int", nullable: false),
                    ElectricMotor = table.Column<bool>(type: "bit", nullable: false),
                    Basket = table.Column<bool>(type: "bit", nullable: false),
                    Color = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: true),
                    All_Terrain = table.Column<bool>(type: "bit", nullable: false),
                    Child_Seat = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SpecialFeatures", x => x.FeatureID);
                });

            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    EmployeeID = table.Column<int>(type: "int", nullable: false),
                    ShopID = table.Column<int>(type: "int", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(13)", maxLength: 13, nullable: false),
                    FName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    LName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Password = table.Column<string>(type: "varchar(max)", unicode: false, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.EmployeeID);
                    table.ForeignKey(
                        name: "FK_Employees_Shops",
                        column: x => x.ShopID,
                        principalTable: "Shops",
                        principalColumn: "ShopID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Bikes",
                columns: table => new
                {
                    BikeID = table.Column<int>(type: "int", nullable: false),
                    TypeID = table.Column<int>(type: "int", nullable: false),
                    Size = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    Location = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    RateID = table.Column<int>(type: "int", nullable: false),
                    FeatureID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bikes", x => x.BikeID);
                    table.ForeignKey(
                        name: "FK_Bikes_RentalRates",
                        column: x => x.RateID,
                        principalTable: "RentalRates",
                        principalColumn: "RateID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Bikes_SpecialFeatures",
                        column: x => x.FeatureID,
                        principalTable: "SpecialFeatures",
                        principalColumn: "FeatureID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "BikesInShop",
                columns: table => new
                {
                    ShopID = table.Column<int>(type: "int", nullable: false),
                    BikeID = table.Column<int>(type: "int", nullable: true),
                    DateTime_In = table.Column<DateTime>(type: "datetime", nullable: false),
                    DateTime_Out = table.Column<DateTime>(type: "datetime", nullable: false),
                    OtherDetails = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BikesInShop", x => x.ShopID);
                    table.ForeignKey(
                        name: "FK_BikesInShop_Bikes",
                        column: x => x.BikeID,
                        principalTable: "Bikes",
                        principalColumn: "BikeID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BikesInShop_Shops",
                        column: x => x.ShopID,
                        principalTable: "Shops",
                        principalColumn: "ShopID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "BikeType",
                columns: table => new
                {
                    TypeID = table.Column<int>(type: "int", nullable: false),
                    MountainBike = table.Column<bool>(type: "bit", nullable: false),
                    StreetBike = table.Column<bool>(type: "bit", nullable: false),
                    BeachCruiser = table.Column<bool>(type: "bit", nullable: false),
                    Moped = table.Column<bool>(type: "bit", nullable: false),
                    TandemBike = table.Column<bool>(type: "bit", nullable: false),
                    Unicycle = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.ForeignKey(
                        name: "FK_BikeType_Bikes",
                        column: x => x.TypeID,
                        principalTable: "Bikes",
                        principalColumn: "BikeID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Rentals",
                columns: table => new
                {
                    RentalID = table.Column<int>(type: "int", nullable: false),
                    BikeID = table.Column<int>(type: "int", nullable: false),
                    CustID = table.Column<int>(type: "int", nullable: false),
                    RateID = table.Column<int>(type: "int", nullable: false),
                    PaymentStatusCode = table.Column<int>(type: "int", nullable: false),
                    Booked_Start_DateTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    Booked_End_DateTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    Actual_Start_DateTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    Actual_End_DateTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    Rental_Payment_Due = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: false),
                    Rental_Payment_Made = table.Column<string>(type: "nchar(3)", fixedLength: true, maxLength: 3, nullable: true),
                    OtherDetails = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rentals", x => x.RentalID);
                    table.ForeignKey(
                        name: "FK_Rentals_Bikes",
                        column: x => x.BikeID,
                        principalTable: "Bikes",
                        principalColumn: "BikeID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Rentals_Customers",
                        column: x => x.CustID,
                        principalTable: "Customers",
                        principalColumn: "CustID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Rentals_PaymentStatus",
                        column: x => x.PaymentStatusCode,
                        principalTable: "PaymentStatus",
                        principalColumn: "PaymentStatusCode",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "RentalDetails",
                columns: table => new
                {
                    RentalID = table.Column<int>(type: "int", nullable: false),
                    Qty = table.Column<int>(type: "int", nullable: false),
                    BikeID = table.Column<int>(type: "int", nullable: false),
                    RateID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.ForeignKey(
                        name: "FK_RentalDetails_Bikes",
                        column: x => x.BikeID,
                        principalTable: "Bikes",
                        principalColumn: "BikeID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RentalDetails_RentalRates",
                        column: x => x.RateID,
                        principalTable: "RentalRates",
                        principalColumn: "RateID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RentalDetails_Rentals",
                        column: x => x.RentalID,
                        principalTable: "Rentals",
                        principalColumn: "RentalID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Bikes_FeatureID",
                table: "Bikes",
                column: "FeatureID");

            migrationBuilder.CreateIndex(
                name: "IX_Bikes_RateID",
                table: "Bikes",
                column: "RateID");

            migrationBuilder.CreateIndex(
                name: "IX_BikesInShop_BikeID",
                table: "BikesInShop",
                column: "BikeID");

            migrationBuilder.CreateIndex(
                name: "IX_BikeType_TypeID",
                table: "BikeType",
                column: "TypeID");

            migrationBuilder.CreateIndex(
                name: "IX_Employees_ShopID",
                table: "Employees",
                column: "ShopID");

            migrationBuilder.CreateIndex(
                name: "IX_RentalDetails_BikeID",
                table: "RentalDetails",
                column: "BikeID");

            migrationBuilder.CreateIndex(
                name: "IX_RentalDetails_RateID",
                table: "RentalDetails",
                column: "RateID");

            migrationBuilder.CreateIndex(
                name: "IX_RentalDetails_RentalID",
                table: "RentalDetails",
                column: "RentalID");

            migrationBuilder.CreateIndex(
                name: "IX_Rentals_BikeID",
                table: "Rentals",
                column: "BikeID");

            migrationBuilder.CreateIndex(
                name: "IX_Rentals_CustID",
                table: "Rentals",
                column: "CustID");

            migrationBuilder.CreateIndex(
                name: "IX_Rentals_PaymentStatusCode",
                table: "Rentals",
                column: "PaymentStatusCode");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BikesInShop");

            migrationBuilder.DropTable(
                name: "BikeType");

            migrationBuilder.DropTable(
                name: "Employees");

            migrationBuilder.DropTable(
                name: "RentalDetails");

            migrationBuilder.DropTable(
                name: "Shops");

            migrationBuilder.DropTable(
                name: "Rentals");

            migrationBuilder.DropTable(
                name: "Bikes");

            migrationBuilder.DropTable(
                name: "Customers");

            migrationBuilder.DropTable(
                name: "PaymentStatus");

            migrationBuilder.DropTable(
                name: "RentalRates");

            migrationBuilder.DropTable(
                name: "SpecialFeatures");
        }
    }
}
