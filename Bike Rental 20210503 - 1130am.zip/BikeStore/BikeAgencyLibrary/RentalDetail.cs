﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BikeAgencyLibrary
{
    public partial class RentalDetail
    {
        public int RentalId { get; set; }
        public int Qty { get; set; }
        public int BikeId { get; set; }
        public int RateId { get; set; }

        public virtual Bike Bike { get; set; }
        public virtual RentalRate Rate { get; set; }
        public virtual Rental Rental { get; set; }
    }
}
