﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BikeAgencyLibrary
{
    public partial class RentalRate
    {
        public RentalRate()
        {
            Bikes = new HashSet<Bike>();
        }

        public int RateId { get; set; }
        public decimal? DailyRate { get; set; }
        public decimal? HourlyRate { get; set; }

        public virtual ICollection<Bike> Bikes { get; set; }
    }
}
